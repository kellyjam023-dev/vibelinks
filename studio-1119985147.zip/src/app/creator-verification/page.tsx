
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, FileText, Camera, Clock, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CreatorVerificationPage() {
  const [status, setStatus] = useState<'unverified' | 'pending' | 'verified'>('unverified');
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    const currentStatus = localStorage.getItem('vibelinks-verification') as any;
    if (currentStatus) setStatus(currentStatus);
  }, []);

  const handleSubmit = () => {
    setStatus('pending');
    localStorage.setItem('vibelinks-verification', 'pending');
    toast({ title: "Application Submitted", description: "Our team will review your profile manually." });
  };

  if (status === 'verified') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6 text-center">
        <div className="space-y-6 max-w-md">
          <div className="h-20 w-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="h-10 w-10" />
          </div>
          <h1 className="text-3xl font-bold">You're Verified!</h1>
          <p className="text-muted-foreground">Your creator status is active. You can now start broadcasting to your fans.</p>
          <Button onClick={() => router.push('/dashboard')} className="w-full h-12 rounded-xl">Go to Dashboard</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="max-w-md w-full border-none shadow-xl bg-white rounded-3xl overflow-hidden">
        <div className="bg-primary p-6 text-white text-center space-y-2">
          <ShieldCheck className="h-12 w-12 mx-auto mb-2" />
          <h1 className="text-2xl font-bold">Creator Verification</h1>
          <p className="text-primary-foreground/80 text-sm">To ensure the safety of our community, all creators must be manually verified.</p>
        </div>
        
        <CardContent className="p-6 space-y-6">
          {status === 'pending' ? (
            <div className="text-center py-8 space-y-4">
              <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full mx-auto" />
              <div className="space-y-2">
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">Under Review</Badge>
                <h2 className="text-xl font-bold">Verification in Progress</h2>
                <p className="text-sm text-muted-foreground leading-relaxed px-4">
                  We've received your application. Manual verification usually takes 24-48 hours. We'll notify you via Activity tab once done.
                </p>
              </div>
              <Button variant="outline" onClick={() => router.push('/dashboard')} className="w-full">Return Home</Button>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <h3 className="font-bold flex items-center gap-2">
                  <FileText className="h-4 w-4 text-primary" />
                  Required Steps
                </h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-4 p-4 rounded-2xl bg-muted/30 border border-muted">
                    <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center font-bold text-xs shrink-0">1</div>
                    <div>
                      <p className="text-sm font-bold">Identity Verification</p>
                      <p className="text-xs text-muted-foreground">Upload a government-issued ID.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-4 rounded-2xl bg-muted/30 border border-muted">
                    <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center font-bold text-xs shrink-0">2</div>
                    <div>
                      <p className="text-sm font-bold">Face Match</p>
                      <p className="text-xs text-muted-foreground">Take a quick selfie holding your ID.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-accent/5 p-4 rounded-2xl border border-accent/10 flex gap-3">
                <Clock className="h-5 w-5 text-accent shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">Manual verification protects users and ensures high-quality creator content on Vibelinks.</p>
              </div>

              <Button 
                className="w-full h-14 rounded-2xl text-lg font-bold bg-accent hover:bg-accent/90"
                onClick={handleSubmit}
              >
                Submit Application
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
