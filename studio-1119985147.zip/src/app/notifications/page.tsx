
"use client";

import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Sparkles, DollarSign, ArrowUpRight, MessageSquare } from "lucide-react";

const userNotifications = [
  { id: "1", type: "session", title: "Aria Bloom is Live!", message: "New session started. You have 45 mins left.", time: "2h ago", avatar: PlaceHolderImages[0].imageUrl, read: false },
  { id: "2", type: "content", title: "Content Unlocked", message: "You purchased 'Midnight Mix' from Aria Bloom.", time: "5h ago", avatar: PlaceHolderImages[0].imageUrl, read: true },
];

const creatorNotifications = [
  { id: "1", type: "sale", title: "Content Sold!", message: "User Alex purchased 'Vibe Set' for $3.99.", time: "10m ago", avatar: "https://picsum.photos/seed/user1/100/100", read: false },
  { id: "2", type: "session", title: "New Session Request", message: "User Sarah started a 45-min session with you.", time: "1h ago", avatar: "https://picsum.photos/seed/user2/100/100", read: false },
  { id: "3", type: "withdrawal", title: "Withdrawal Processed", message: "Your withdrawal of $150.00 was successful.", time: "Yesterday", avatar: null, read: true },
];

export default function NotificationsPage() {
  const [role, setRole] = useState<'user' | 'creator' | null>(null);

  useEffect(() => {
    setRole(localStorage.getItem('vibelinks-role') as any);
  }, []);

  const notifications = role === 'creator' ? creatorNotifications : userNotifications;

  return (
    <AppShell>
      <div className="p-6 space-y-6">
        <header className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Activity</h1>
          <Badge variant="outline" className="text-[10px]">Mark all as read</Badge>
        </header>

        <div className="space-y-3">
          {notifications.map((notif) => (
            <div 
              key={notif.id} 
              className={`p-4 rounded-2xl border flex gap-4 transition-colors ${notif.read ? 'bg-white' : 'bg-primary/5 border-primary/20'}`}
            >
              <div className="relative shrink-0">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={notif.avatar || ""} />
                  <AvatarFallback>{notif.type === 'withdrawal' ? 'VC' : 'U'}</AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1 p-1 bg-white rounded-full shadow-sm border">
                  {notif.type === 'sale' && <DollarSign className="h-3 w-3 text-green-500" />}
                  {notif.type === 'session' && <MessageSquare className="h-3 w-3 text-primary" />}
                  {notif.type === 'withdrawal' && <ArrowUpRight className="h-3 w-3 text-accent" />}
                  {notif.type === 'content' && <Sparkles className="h-3 w-3 text-yellow-500" />}
                </div>
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex justify-between items-start">
                  <h3 className={`text-sm font-bold ${notif.read ? 'text-foreground' : 'text-primary'}`}>{notif.title}</h3>
                  <span className="text-[10px] text-muted-foreground">{notif.time}</span>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">{notif.message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
