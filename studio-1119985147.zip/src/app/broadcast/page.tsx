
import { AppShell } from "@/components/layout/app-shell";
import { BroadcastTool } from "@/components/broadcast/broadcast-tool";
import { Badge } from "@/components/ui/badge";
import { Users, Zap } from "lucide-react";

export default function BroadcastPage() {
  return (
    <AppShell>
      <div className="p-6 space-y-8">
        <header className="space-y-2">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Creator Studio</h1>
            <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-100 border-none">
              Live Now
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">Manage your presence and broadcast to fans.</p>
        </header>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-2xl shadow-sm border space-y-1">
            <p className="text-xs text-muted-foreground font-medium uppercase">Active Fans</p>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <span className="text-xl font-bold">1,204</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm border space-y-1">
            <p className="text-xs text-muted-foreground font-medium uppercase">Sessions Today</p>
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-500" />
              <span className="text-xl font-bold">48</span>
            </div>
          </div>
        </div>

        <BroadcastTool />

        <section className="space-y-4 pt-4">
          <h2 className="font-bold">Recent Broadcasts</h2>
          <div className="space-y-3">
            {[
              { time: "2h ago", text: "New Midnight Mix is out! Check the marketplace in my chat.", reaches: 850 },
              { time: "Yesterday", text: "Going live in 5! Grab a session and let's talk music.", reaches: 1100 },
            ].map((item, i) => (
              <div key={i} className="p-4 bg-white border rounded-2xl flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{item.time}</p>
                  <p className="text-sm line-clamp-2">{item.text}</p>
                </div>
                <Badge variant="outline" className="text-[10px] shrink-0">{item.reaches} seen</Badge>
              </div>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
