
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, ChevronLeft, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const { toast } = useToast();

  const handleLogin = () => {
    if (!email || !password) {
      toast({ title: "Missing Info", description: "Please enter your email and password.", variant: "destructive" });
      return;
    }

    // Mock login logic
    const savedEmail = localStorage.getItem('vibelinks-email');
    const role = localStorage.getItem('vibelinks-role') || 'user';

    if (savedEmail && email !== savedEmail) {
      toast({ title: "Login Failed", description: "Invalid credentials.", variant: "destructive" });
      return;
    }

    localStorage.setItem('vibelinks-role', role);
    window.dispatchEvent(new Event('storage'));

    toast({ title: "Welcome back!", description: "You are now logged in." });
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-accent/10 rounded-full blur-3xl" />

      <div className="w-full max-w-md space-y-6 z-10">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm font-medium">
          <ChevronLeft className="h-4 w-4" />
          Back to home
        </Link>

        <Card className="border-none shadow-2xl bg-white rounded-[2.5rem] overflow-hidden">
          <CardHeader className="text-center pt-10 pb-6 space-y-2">
            <div className="mx-auto bg-primary/10 w-16 h-16 rounded-3xl flex items-center justify-center mb-2">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-3xl font-bold text-accent">Welcome Back</CardTitle>
            <CardDescription className="text-base">Enter your credentials to continue.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 pb-10 px-8">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Email Address</Label>
                <Input 
                  id="email" 
                  type="email"
                  placeholder="alex@example.com" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="rounded-2xl h-12 border-muted focus-visible:ring-primary px-6"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Password</Label>
                <Input 
                  id="password" 
                  type="password"
                  placeholder="••••••••" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="rounded-2xl h-12 border-muted focus-visible:ring-primary px-6"
                />
              </div>
            </div>

            <Button 
              className="w-full h-14 rounded-2xl text-lg font-bold bg-accent hover:bg-accent/90 shadow-xl shadow-accent/20 transition-all active:scale-[0.98]"
              onClick={handleLogin}
            >
              Log In
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>

            <div className="text-center">
              <p className="text-xs text-muted-foreground">
                Don't have an account?{" "}
                <Link href="/signup" className="text-primary font-bold hover:underline">
                  Sign Up
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
