
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Link from "next/link";
import { 
  Sparkles, 
  ArrowRight, 
  ShieldAlert, 
  Video, 
  DollarSign, 
  MessageSquarePlus, 
  Lightbulb,
  Star,
  TrendingUp
} from "lucide-react";

const featuredCreators = [
  {
    id: "c1",
    name: "Aria Bloom",
    tagline: "Live DJ sets & vibe check",
    tags: ["Music", "Chill"],
    avatar: PlaceHolderImages[0].imageUrl,
  },
  {
    id: "c2",
    name: "Marcus Ink",
    tagline: "Digital art creation",
    tags: ["Art", "Design"],
    avatar: PlaceHolderImages[1].imageUrl,
  },
  {
    id: "c3",
    name: "Elena Chef",
    tagline: "Quick recipes for busy days",
    tags: ["Food", "Cooking"],
    avatar: PlaceHolderImages[2].imageUrl,
  },
];

export default function DashboardPage() {
  const [role, setRole] = useState<'user' | 'creator' | null>(null);
  const [verification, setVerification] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const savedRole = localStorage.getItem('vibelinks-role') as 'user' | 'creator';
    if (!savedRole) {
      router.push('/');
      return;
    }
    setRole(savedRole);
    setVerification(localStorage.getItem('vibelinks-verification'));
    setIsLoaded(true);
  }, [router]);

  if (!isLoaded) return null;

  return (
    <AppShell>
      <div className="p-6 space-y-8">
        {role === 'user' ? (
          <>
            <header className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-accent">Vibelinks</h1>
                <p className="text-muted-foreground text-sm">Exclusive 45-min moments</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-primary text-primary px-3 py-1 h-9 flex items-center">
                  $0.99 Session
                </Badge>
              </div>
            </header>

            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  Online Now
                </h2>
                <Link href="/explore" className="text-primary text-sm font-medium">See all</Link>
              </div>
              
              <div className="space-y-4">
                {featuredCreators.map((creator) => (
                  <Card key={creator.id} className="overflow-hidden border-none shadow-md hover:shadow-lg transition-shadow bg-white rounded-3xl">
                    <CardContent className="p-4 flex items-center gap-4">
                      <Avatar className="h-16 w-16 border-2 border-primary/20">
                        <AvatarImage src={creator.avatar} />
                        <AvatarFallback>{creator.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-bold text-lg">{creator.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-1">{creator.tagline}</p>
                        <div className="flex gap-1 mt-2">
                          {creator.tags.map(tag => (
                            <Badge key={tag} variant="secondary" className="text-[10px] px-2 py-0 h-4">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <Link href={`/chat/${creator.id}`}>
                        <Button size="icon" className="rounded-full h-10 w-10 bg-primary">
                          <ArrowRight className="h-5 w-5" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            <section className="bg-accent/5 rounded-3xl p-6 space-y-3 border border-accent/10">
              <h2 className="font-bold text-accent flex items-center gap-2">
                <Lightbulb className="h-4 w-4" />
                How it works
              </h2>
              <ul className="space-y-4 text-sm">
                <li className="flex gap-3">
                  <div className="bg-accent text-white h-6 w-6 rounded-full flex items-center justify-center shrink-0 font-bold text-xs">1</div>
                  <p>Pick a creator and pay <span className="font-bold text-accent">$0.99</span> for a 45-minute private session.</p>
                </li>
                <li className="flex gap-3">
                  <div className="bg-accent text-white h-6 w-6 rounded-full flex items-center justify-center shrink-0 font-bold text-xs">2</div>
                  <p>Chat directly and buy exclusive content for <span className="font-bold text-accent">$3.99</span> inside.</p>
                </li>
                <li className="flex gap-3">
                  <div className="bg-accent text-white h-6 w-6 rounded-full flex items-center justify-center shrink-0 font-bold text-xs">3</div>
                  <p>Sessions end automatically after 45 mins. Start another for the same low price!</p>
                </li>
              </ul>
            </section>
          </>
        ) : (
          <>
            <header className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-accent">Studio</h1>
                <p className="text-muted-foreground text-sm">Ready to vibe with your fans?</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-green-500 text-green-600 px-3 py-1 h-9 flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                  Live Status
                </Badge>
              </div>
            </header>

            {verification !== 'verified' && (
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-2xl flex gap-3 items-center">
                <ShieldAlert className="h-5 w-5 text-yellow-600 shrink-0" />
                <div className="flex-1">
                  <p className="text-sm font-bold text-yellow-800">Verification Required</p>
                  <p className="text-xs text-yellow-700">Complete verification to start broadcasting.</p>
                </div>
                <Link href="/creator-verification">
                  <Button size="sm" variant="outline" className="h-8 text-[10px] uppercase font-bold border-yellow-300 hover:bg-yellow-100">Verify</Button>
                </Link>
              </div>
            )}

            <section className="space-y-4">
              <Link href={verification === 'verified' ? "/broadcast" : "/creator-verification"}>
                <Card className="bg-primary text-white border-none shadow-xl overflow-hidden cursor-pointer group active:scale-[0.98] transition-all rounded-[2.5rem]">
                  <CardContent className="p-8 flex flex-col items-center text-center space-y-6">
                    <div className="bg-white/20 p-5 rounded-full ring-8 ring-white/10 group-hover:ring-white/20 transition-all">
                      <Video className="h-10 w-10 text-white" />
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-3xl font-bold">Go Live Now</h2>
                      <p className="text-primary-foreground/80 text-sm max-w-[200px] mx-auto">
                        Start a broadcast and let your fans join private 45-min sessions.
                      </p>
                    </div>
                    <Button className="bg-white text-primary hover:bg-white/90 font-bold rounded-full px-10 h-12 text-lg">
                      Enter Studio
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Creator Performance Tips
              </h2>
              
              <div className="grid gap-4">
                <Card className="border-none shadow-sm bg-white hover:shadow-md transition-shadow rounded-2xl">
                  <CardContent className="p-4 flex gap-4">
                    <div className="h-12 w-12 rounded-2xl bg-blue-50 flex items-center justify-center shrink-0">
                      <Star className="h-6 w-6 text-blue-500" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold text-sm">Send a Teasing Video</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Drop a 10-second teasing clip in your broadcast gallery to fill your session queue instantly.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-sm bg-white hover:shadow-md transition-shadow rounded-2xl">
                  <CardContent className="p-4 flex gap-4">
                    <div className="h-12 w-12 rounded-2xl bg-green-50 flex items-center justify-center shrink-0">
                      <DollarSign className="h-6 w-6 text-green-500" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold text-sm">Encourage Extensions</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Remind fans to extend sessions for another 45 mins to keep the vibe going and increase your earnings.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-sm bg-white hover:shadow-md transition-shadow rounded-2xl">
                  <CardContent className="p-4 flex gap-4">
                    <div className="h-12 w-12 rounded-2xl bg-purple-50 flex items-center justify-center shrink-0">
                      <MessageSquarePlus className="h-6 w-6 text-purple-500" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold text-sm">Sell Exclusive Content</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Drop custom mixes or artwork for $3.99 in the chat marketplace. It's the most effective way to monetize your talent.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </section>
          </>
        )}
      </div>
    </AppShell>
  );
}
