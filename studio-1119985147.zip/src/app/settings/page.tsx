
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { AppShell } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  User, 
  Bell, 
  Shield, 
  CreditCard, 
  Banknote, 
  ChevronLeft, 
  Save,
  Globe,
  Lock,
  HelpCircle,
  FileText,
  Info,
  Mail,
  Headphones,
  Moon,
  Sun,
  Palette
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

export default function SettingsPage() {
  const { toast } = useToast();
  const router = useRouter();
  const [role, setRole] = useState<'user' | 'creator' | null>(null);
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const savedRole = localStorage.getItem('vibelinks-role') as 'user' | 'creator';
    const savedName = localStorage.getItem('vibelinks-name');
    const theme = localStorage.getItem('vibelinks-theme');
    
    if (!savedRole) {
      router.push('/signup');
      return;
    }
    
    setRole(savedRole);
    setName(savedName || "");
    setBio(savedRole === 'creator' ? "Sharing the vibes and exclusive mixes. Join my private sessions for a custom experience! 🎵✨" : "");
    setIsDark(theme === 'dark');
  }, [router]);

  const toggleTheme = (checked: boolean) => {
    setIsDark(checked);
    if (checked) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('vibelinks-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('vibelinks-theme', 'light');
    }
  };

  const handleSave = (section: string) => {
    if (section === 'profile') {
      localStorage.setItem('vibelinks-name', name);
    }
    toast({
      title: "Settings Saved",
      description: `Your ${section} preferences have been updated.`,
    });
  };

  const handleLiveChat = () => {
    toast({
      title: "Connecting...",
      description: "A support agent will be with you shortly.",
    });
  };

  if (!role) return null;

  return (
    <AppShell>
      <div className="p-6 space-y-6">
        <header className="flex items-center gap-4">
          <Link href="/profile">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Settings</h1>
        </header>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid grid-cols-6 w-full bg-muted/50 p-1 rounded-xl">
            <TabsTrigger value="profile" className="rounded-lg text-[9px] px-1"><User className="h-4 w-4 sm:hidden" /> <span className="hidden sm:inline">Profile</span></TabsTrigger>
            <TabsTrigger value="notifications" className="rounded-lg text-[9px] px-1"><Bell className="h-4 w-4 sm:hidden" /> <span className="hidden sm:inline">Alerts</span></TabsTrigger>
            <TabsTrigger value="appearance" className="rounded-lg text-[9px] px-1"><Palette className="h-4 w-4 sm:hidden" /> <span className="hidden sm:inline">Theme</span></TabsTrigger>
            <TabsTrigger value="privacy" className="rounded-lg text-[9px] px-1"><Shield className="h-4 w-4 sm:hidden" /> <span className="hidden sm:inline">Privacy</span></TabsTrigger>
            <TabsTrigger value="billing" className="rounded-lg text-[9px] px-1">
              {role === 'creator' ? <Banknote className="h-4 w-4 sm:hidden" /> : <CreditCard className="h-4 w-4 sm:hidden" />}
              <span className="hidden sm:inline">{role === 'creator' ? 'Payouts' : 'Billing'}</span>
            </TabsTrigger>
            <TabsTrigger value="support" className="rounded-lg text-[9px] px-1"><HelpCircle className="h-4 w-4 sm:hidden" /> <span className="hidden sm:inline">Support</span></TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <Card className="border-none shadow-sm bg-white dark:bg-card rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg">Public Profile</CardTitle>
                <CardDescription>Manage how you appear to others on Vibelinks.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="display-name">Display Name</Label>
                  <Input 
                    id="display-name" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)}
                    className="rounded-xl h-11"
                  />
                </div>
                {role === 'creator' && (
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea 
                      id="bio" 
                      value={bio} 
                      onChange={(e) => setBio(e.target.value)}
                      placeholder="Tell your fans what they can expect..."
                      className="min-h-[100px] rounded-xl"
                    />
                  </div>
                )}
                <Button className="w-full rounded-xl bg-primary" onClick={() => handleSave('profile')}>
                  <Save className="h-4 w-4 mr-2" /> Save Profile
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4">
            <Card className="border-none shadow-sm bg-white dark:bg-card rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg">Notification Settings</CardTitle>
                <CardDescription>Control when and how you're notified.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Push Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive alerts on your device.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Session Requests</Label>
                    <p className="text-xs text-muted-foreground">When a fan starts a 45-min session.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Content Sales</Label>
                    <p className="text-xs text-muted-foreground">Notify me when content is unlocked.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4">
            <Card className="border-none shadow-sm bg-white dark:bg-card rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg">Appearance</CardTitle>
                <CardDescription>Customize your Vibelinks experience.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      {isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4 text-yellow-500" />}
                      Dark Mode
                    </Label>
                    <p className="text-xs text-muted-foreground">Switch between light and dark themes.</p>
                  </div>
                  <Switch checked={isDark} onCheckedChange={toggleTheme} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy" className="space-y-4">
            <Card className="border-none shadow-sm bg-white dark:bg-card rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg">Account Security</CardTitle>
                <CardDescription>Keep your account safe and private.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      Public Presence
                    </Label>
                    <p className="text-xs text-muted-foreground">Allow others to see when you're online.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Lock className="h-4 w-4 text-muted-foreground" />
                      Two-Factor Auth
                    </Label>
                    <p className="text-xs text-muted-foreground">Add an extra layer of security.</p>
                  </div>
                  <Switch />
                </div>
                <Button variant="outline" className="w-full rounded-xl border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600">
                  Deactivate Account
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing" className="space-y-4">
            <Card className="border-none shadow-sm bg-white dark:bg-card rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg">{role === 'creator' ? 'Payout Details' : 'Payment Methods'}</CardTitle>
                <CardDescription>
                  {role === 'creator' ? 'Connect your bank account to receive earnings.' : 'Manage your cards for session purchases.'}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {role === 'creator' ? (
                  <div className="space-y-4">
                    <div className="p-4 bg-muted/30 dark:bg-muted/10 border rounded-xl space-y-2">
                      <p className="text-xs font-bold uppercase text-muted-foreground">Linked Bank Account</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Banknote className="h-5 w-5 text-primary" />
                          <span className="font-medium">CHASE **** 8920</span>
                        </div>
                        <Button variant="ghost" size="sm" className="text-xs text-primary">Change</Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Payout Frequency</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" className="rounded-lg h-10 text-xs">Weekly</Button>
                        <Button variant="default" className="rounded-lg h-10 text-xs bg-primary">Instant (Daily)</Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                     <div className="p-4 bg-muted/30 dark:bg-muted/10 border rounded-xl space-y-2">
                      <p className="text-xs font-bold uppercase text-muted-foreground">Active Card</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CreditCard className="h-5 w-5 text-primary" />
                          <span className="font-medium">VISA **** 4412</span>
                        </div>
                        <Button variant="ghost" size="sm" className="text-xs text-primary">Edit</Button>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full rounded-xl border-dashed">
                      Add New Card
                    </Button>
                  </div>
                )}
                <Button className="w-full rounded-xl bg-accent" onClick={() => handleSave('financials')}>
                  Save Changes
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="support" className="space-y-4">
            <Card className="border-none shadow-sm bg-white dark:bg-card rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg">Support & Information</CardTitle>
                <CardDescription>Everything you need to know about using Vibelinks.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="contact" className="border-none px-6">
                    <AccordionTrigger className="hover:no-underline py-4">
                      <div className="flex items-center gap-3">
                        <Headphones className="h-5 w-5 text-primary" />
                        <span className="font-medium">Contact Support</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-4 pb-6">
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 dark:bg-muted/10 border">
                          <Mail className="h-5 w-5 text-primary" />
                          <div>
                            <p className="text-[10px] uppercase font-bold text-muted-foreground">Email Us</p>
                            <p className="text-sm font-medium">support@vibelinks.app</p>
                          </div>
                        </div>
                        <Button 
                          className="w-full rounded-xl bg-accent h-12 flex items-center justify-center gap-2 text-white"
                          onClick={handleLiveChat}
                        >
                          <Headphones className="h-5 w-5" />
                          Start Live Chat
                        </Button>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="faq" className="border-t px-6">
                    <AccordionTrigger className="hover:no-underline py-4">
                      <div className="flex items-center gap-3">
                        <HelpCircle className="h-5 w-5 text-primary" />
                        <span className="font-medium">Frequently Asked Questions</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground space-y-4 pb-6">
                      <div className="space-y-2">
                        <p className="font-bold text-foreground">How long is each session?</p>
                        <p className="text-sm">Every private session on Vibelinks lasts for exactly 45 minutes. You can start a new session immediately after one ends.</p>
                      </div>
                      <div className="space-y-2">
                        <p className="font-bold text-foreground">What does a session cost?</p>
                        <p className="text-sm">Sessions are priced at a flat rate of $0.99 for 45 minutes of private interaction.</p>
                      </div>
                      <div className="space-y-2">
                        <p className="font-bold text-foreground">How do I buy exclusive content?</p>
                        <p className="text-sm">Inside any active chat, creators can drop exclusive content into the marketplace. These items usually cost $3.99 and are permanently added to your collection.</p>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="terms" className="border-t px-6">
                    <AccordionTrigger className="hover:no-underline py-4">
                      <div className="flex items-center gap-3">
                        <FileText className="h-5 w-5 text-primary" />
                        <span className="font-medium">Terms & Conditions</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground space-y-4 text-xs pb-6 leading-relaxed">
                      <p>By using Vibelinks, you agree to our platform guidelines. All payments are final and non-refundable given the nature of digital services.</p>
                      <p>Creators are independent contractors and are responsible for the content they provide. Vibelinks maintains a zero-tolerance policy for harassment or illegal activities.</p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="about" className="border-t px-6">
                    <AccordionTrigger className="hover:no-underline py-4">
                      <div className="flex items-center gap-3">
                        <Info className="h-5 w-5 text-primary" />
                        <span className="font-medium">About the App</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground space-y-4 pb-6">
                      <p className="text-sm">Vibelinks is the world's first premium connection platform designed for meaningful, time-boxed interactions between creators and fans.</p>
                      <p className="text-sm">Our mission is to democratize access to creators while ensuring they are fairly compensated for their time and talent.</p>
                      <div className="pt-2 text-[10px] uppercase tracking-widest text-center">
                        Vibelinks Version 1.2.0 • Made with ❤️ for Creators
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}
