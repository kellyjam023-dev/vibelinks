
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, ShieldCheck, ArrowRight, Check, ChevronLeft, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

export default function SignupPage() {
  const [role, setRole] = useState<'user' | 'creator' | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const { toast } = useToast();

  const handleSignup = () => {
    if (!role || !name || !email || !password) {
      toast({ title: "Missing Info", description: "Please fill in all fields and choose a role.", variant: "destructive" });
      return;
    }

    // Mock signup logic
    localStorage.setItem('vibelinks-role', role);
    localStorage.setItem('vibelinks-name', name);
    localStorage.setItem('vibelinks-email', email);
    localStorage.setItem('vibelinks-verification', role === 'creator' ? 'unverified' : 'verified');
    
    window.dispatchEvent(new Event('storage'));

    toast({ title: "Welcome to Vibelinks!", description: "Account created successfully." });

    if (role === 'creator') {
      router.push('/creator-verification');
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-accent/10 rounded-full blur-3xl" />

      <div className="w-full max-w-md space-y-6 z-10">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm font-medium">
          <ChevronLeft className="h-4 w-4" />
          Back to home
        </Link>

        <Card className="border-none shadow-2xl bg-white rounded-[2.5rem] overflow-hidden">
          <CardHeader className="text-center pt-10 pb-6 space-y-2">
            <div className="mx-auto bg-primary/10 w-16 h-16 rounded-3xl flex items-center justify-center mb-2">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-3xl font-bold text-accent">Join Vibelinks</CardTitle>
            <CardDescription className="text-base">Start your premium connection journey.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 pb-10 px-8">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Full Name</Label>
                <Input 
                  id="name" 
                  placeholder="e.g. Alex Bloom" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="rounded-2xl h-12 border-muted focus-visible:ring-primary px-6"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Email Address</Label>
                <Input 
                  id="email" 
                  type="email"
                  placeholder="alex@example.com" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="rounded-2xl h-12 border-muted focus-visible:ring-primary px-6"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Password</Label>
                <Input 
                  id="password" 
                  type="password"
                  placeholder="••••••••" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="rounded-2xl h-12 border-muted focus-visible:ring-primary px-6"
                />
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1">Choose your vibe</Label>
              <div className="grid grid-cols-1 gap-3">
                <button
                  onClick={() => setRole('user')}
                  className={cn(
                    "group flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all relative overflow-hidden",
                    role === 'user' ? "border-primary bg-primary/5 ring-4 ring-primary/5" : "border-muted hover:border-primary/30"
                  )}
                >
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shrink-0 transition-colors", role === 'user' ? "bg-primary text-white" : "bg-muted text-muted-foreground group-hover:bg-primary/10")}>
                    <User className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm">I'm a Fan</p>
                    <p className="text-[10px] text-muted-foreground leading-snug">Discover creators and join sessions.</p>
                  </div>
                  {role === 'user' && <Check className="h-4 w-4 text-primary" />}
                </button>

                <button
                  onClick={() => setRole('creator')}
                  className={cn(
                    "group flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all relative overflow-hidden",
                    role === 'creator' ? "border-primary bg-primary/5 ring-4 ring-primary/5" : "border-muted hover:border-primary/30"
                  )}
                >
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shrink-0 transition-colors", role === 'creator' ? "bg-primary text-white" : "bg-muted text-muted-foreground group-hover:bg-primary/10")}>
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm">I'm a Creator</p>
                    <p className="text-[10px] text-muted-foreground leading-snug">Go live and earn from your talent.</p>
                  </div>
                  {role === 'creator' && <Check className="h-4 w-4 text-primary" />}
                </button>
              </div>
            </div>

            <Button 
              className="w-full h-14 rounded-2xl text-lg font-bold bg-accent hover:bg-accent/90 shadow-xl shadow-accent/20 transition-all active:scale-[0.98]"
              onClick={handleSignup}
            >
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>

            <div className="text-center">
              <p className="text-xs text-muted-foreground">
                Already have an account?{" "}
                <Link href="/login" className="text-primary font-bold hover:underline">
                  Log In
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
