
"use client";

import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Link from "next/link";
import { ChevronRight } from "lucide-react";

const recentChats = [
  { id: "c1", name: "Aria Bloom", lastMsg: "See you next time! 🎵", time: "10m ago", active: true, avatar: PlaceHolderImages[0].imageUrl },
  { id: "c2", name: "Marcus Ink", lastMsg: "Did you like the final sketch?", time: "2h ago", active: false, avatar: PlaceHolderImages[1].imageUrl },
  { id: "c3", name: "Elena Chef", lastMsg: "The pasta recipe is saved.", time: "Yesterday", active: false, avatar: PlaceHolderImages[2].imageUrl },
];

export default function ChatsPage() {
  const [role, setRole] = useState<'user' | 'creator' | null>(null);

  useEffect(() => {
    setRole(localStorage.getItem('vibelinks-role') as any);
  }, []);

  return (
    <AppShell>
      <div className="p-6 space-y-6">
        <header>
          <h1 className="text-2xl font-bold">Messages</h1>
        </header>

        <section className="space-y-1">
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest px-2 pb-2">
            {role === 'creator' ? 'Client Sessions' : 'Recent Sessions'}
          </h2>
          <div className="divide-y bg-white rounded-2xl shadow-sm border overflow-hidden">
            {recentChats.map((chat) => (
              <Link 
                key={chat.id} 
                href={`/chat/${chat.id}`}
                className="flex items-center gap-4 p-4 hover:bg-accent/5 transition-colors"
              >
                <div className="relative">
                  <Avatar className="h-12 w-12 border border-muted">
                    <AvatarImage src={chat.avatar} />
                    <AvatarFallback>{chat.name[0]}</AvatarFallback>
                  </Avatar>
                  {chat.active && (
                    <div className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 border-2 border-white rounded-full" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-bold text-sm truncate">{chat.name}</h3>
                    <span className="text-[10px] text-muted-foreground">{chat.time}</span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{chat.lastMsg}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground/50 shrink-0" />
              </Link>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
