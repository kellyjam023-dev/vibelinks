
"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Zap, ShieldCheck, Clock } from "lucide-react";
import Link from "next/link";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background font-body flex flex-col">
      {/* Navigation */}
      <nav className="p-6 flex justify-between items-center max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="bg-primary p-2 rounded-xl">
            <Zap className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold text-accent tracking-tight">Vibelinks</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/login">
            <Button variant="ghost" className="text-sm font-bold text-accent">Log In</Button>
          </Link>
          <Link href="/signup">
            <Button className="rounded-full px-6 bg-accent hover:bg-accent/90">Join Now</Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 text-center space-y-8 max-w-3xl mx-auto">
        <Badge className="bg-primary/10 text-primary border-none hover:bg-primary/10 px-4 py-1 rounded-full text-xs font-bold animate-pulse">
          Premium Private Connections
        </Badge>
        
        <div className="space-y-4">
          <h1 className="text-5xl sm:text-7xl font-bold tracking-tight text-accent leading-[1.1]">
            Vibe with your <span className="text-primary italic">fav creators.</span>
          </h1>
          <p className="text-muted-foreground text-lg sm:text-xl max-w-xl mx-auto leading-relaxed">
            Direct, private, and exclusive 45-minute sessions. 
            No noise, just pure connection.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md pt-4">
          <Link href="/signup" className="flex-1">
            <Button className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20 bg-primary hover:bg-primary/90">
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>

        {/* Quick Features */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-12 w-full max-w-lg">
          <div className="flex flex-col items-center space-y-2">
            <div className="h-12 w-12 rounded-full bg-primary/5 flex items-center justify-center mb-2">
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-bold text-sm">45-Min Sessions</h3>
            <p className="text-xs text-muted-foreground">Premium time-boxed chats</p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <div className="h-12 w-12 rounded-full bg-green-50 flex items-center justify-center mb-2">
              <ShieldCheck className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-bold text-sm">Verified Vibes</h3>
            <p className="text-xs text-muted-foreground">Safe & authentic creators</p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="p-8 text-center text-muted-foreground text-[10px] uppercase tracking-widest font-bold">
        <p>© 2026 Vibelinks. Authentic connections only.</p>
      </footer>
    </div>
  );
}
