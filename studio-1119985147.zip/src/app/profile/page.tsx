
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { AppShell } from "@/components/layout/app-shell";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Settings, LogOut, ChevronRight, Star, FileCheck, Grid3X3, Video, Heart, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";
import Link from "next/link";

export default function ProfilePage() {
  const { toast } = useToast();
  const [role, setRole] = useState<'user' | 'creator' | null>(null);
  const [name, setName] = useState("");
  const [verification, setVerification] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const savedRole = localStorage.getItem('vibelinks-role') as 'user' | 'creator';
    const savedName = localStorage.getItem('vibelinks-name');
    const savedVerif = localStorage.getItem('vibelinks-verification');
    
    if (!savedRole) {
      router.push('/signup');
      return;
    }
    
    setRole(savedRole);
    setName(savedName || "Alex Johnson");
    setVerification(savedVerif);
  }, [router]);

  const handleLogout = () => {
    localStorage.clear();
    toast({ title: "Logged out", description: "See you soon!" });
    router.push('/signup');
  };

  const handleUploadPost = () => {
    toast({ title: "Opening Gallery", description: "Select a photo or video to share with your vibes." });
  };

  if (!role) return null;

  return (
    <AppShell>
      <div className="p-6 space-y-8 pb-10">
        <header className="flex flex-col items-center gap-4 pt-6">
          <div className="relative">
            <Avatar className="h-28 w-28 border-4 border-white shadow-xl">
              <AvatarImage src={`https://picsum.photos/seed/${name}/300/300`} />
              <AvatarFallback>{name[0]}</AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-primary text-white border-4 border-white flex items-center justify-center shadow-lg">
              {role === 'creator' ? <Star className="h-4 w-4 fill-current" /> : <Heart className="h-4 w-4 fill-current" />}
            </div>
          </div>
          <div className="text-center space-y-1">
            <h1 className="text-2xl font-bold">{name}</h1>
            <p className="text-muted-foreground text-sm">@{name.toLowerCase().replace(/\s/g, '_')}</p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <div className="flex items-center gap-1 bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full text-xs font-bold">
                <Star className="h-3 w-3 fill-current" />
                {role === 'creator' ? '4.9' : '5.0'}
              </div>
              {role === 'creator' && (
                <Badge variant={verification === 'verified' ? "default" : "secondary"} className="h-5 text-[9px] uppercase">
                  {verification === 'verified' ? "Verified Creator" : "Under Review"}
                </Badge>
              )}
            </div>
          </div>

          <div className="text-center max-w-xs">
            <p className="text-sm text-muted-foreground leading-relaxed italic">
              {role === 'creator' 
                ? "Sharing the vibes and exclusive mixes. Join my private sessions for a custom experience! 🎵✨"
                : "Vibelinks enthusiast. Exploring the best creators and exclusive moments. ✨"}
            </p>
          </div>
          
          <div className="grid grid-cols-3 w-full gap-4 text-center mt-2">
            <div>
              <p className="font-bold text-lg">{role === 'creator' ? '12.4k' : '4.9'}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">{role === 'creator' ? 'Fans' : 'Rating'}</p>
            </div>
            <div>
              <p className="font-bold text-lg">{role === 'creator' ? '482' : '12'}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Sessions</p>
            </div>
            <div>
              <p className="font-bold text-lg">{role === 'creator' ? '98%' : '5'}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">{role === 'creator' ? 'Response' : 'Unlocked'}</p>
            </div>
          </div>
        </header>

        <section className="space-y-4">
          <div className="flex items-center justify-between border-b pb-2">
            <div className="flex items-center gap-2">
              <Grid3X3 className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-bold uppercase tracking-wider">Posts</h2>
            </div>
            <Button variant="ghost" size="sm" className="h-8 text-[10px] uppercase font-bold" onClick={handleUploadPost}>
              <Plus className="h-3 w-3 mr-1" /> New Post
            </Button>
          </div>
          <div className="grid grid-cols-3 gap-1 rounded-2xl overflow-hidden border">
            {[...PlaceHolderImages, ...PlaceHolderImages].slice(0, 9).map((img, i) => (
              <div key={i} className="aspect-square relative group cursor-pointer overflow-hidden">
                <Image src={img.imageUrl} alt="post" fill className="object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                  {i % 3 === 0 ? <Video className="h-5 w-5" /> : <Heart className="h-5 w-5 fill-current" />}
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="space-y-4">
          <Card className="border-none shadow-sm bg-white overflow-hidden">
            <CardContent className="p-0 divide-y">
              {role === 'creator' && verification !== 'verified' && (
                <button 
                  className="w-full flex items-center justify-between p-4 hover:bg-accent/5 transition-colors group bg-yellow-50/50"
                  onClick={() => router.push('/creator-verification')}
                >
                  <div className="flex items-center gap-3">
                    <FileCheck className="h-5 w-5 text-yellow-600" />
                    <span className="font-bold text-sm text-yellow-800 uppercase">Verification Required</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-yellow-600" />
                </button>
              )}
              <Link href="/settings" className="w-full flex items-center justify-between p-4 hover:bg-accent/5 transition-colors">
                <div className="flex items-center gap-3">
                  <Settings className="h-5 w-5 text-gray-500" />
                  <span className="font-medium text-sm">Account Settings</span>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </Link>
            </CardContent>
          </Card>

          <Button 
            variant="ghost" 
            className="w-full text-red-500 hover:text-red-600 hover:bg-red-50 flex items-center gap-2 rounded-xl"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5" />
            Sign Out
          </Button>
        </div>
      </div>
    </AppShell>
  );
}
