
"use client";

import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Wallet, Plus, ArrowUpRight, ArrowDownLeft, Banknote } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function WalletPage() {
  const { toast } = useToast();
  const [role, setRole] = useState<'user' | 'creator' | null>(null);
  const balance = 124.50;

  useEffect(() => {
    setRole(localStorage.getItem('vibelinks-role') as any);
  }, []);

  const transactions = [
    { id: "t1", type: role === 'creator' ? 'sale' : 'session', label: role === 'creator' ? "Sale to Alex" : "Aria Bloom", date: "Oct 24", amount: role === 'creator' ? 3.99 : -0.99 },
    { id: "t2", type: "withdrawal", label: "Bank Transfer", date: "Oct 23", amount: -50.00 },
    { id: "t3", type: "deposit", label: "Wallet Credit", date: "Oct 22", amount: 20.00 },
  ];

  return (
    <AppShell>
      <div className="p-6 space-y-8">
        <header className="space-y-2">
          <h1 className="text-2xl font-bold">Wallet</h1>
          <p className="text-sm text-muted-foreground">
            {role === 'creator' ? "Manage your earnings and payouts." : "Manage your funds for sessions and content."}
          </p>
        </header>

        <Card className="bg-gradient-to-br from-primary to-accent text-white border-none shadow-xl">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center opacity-80">
              <span className="text-xs font-bold uppercase tracking-wider">
                {role === 'creator' ? "Earned Balance" : "Available Balance"}
              </span>
              <Wallet className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-4xl font-bold">${balance.toFixed(2)}</div>
            <div className="flex gap-3">
              {role === 'creator' ? (
                <Button 
                  className="flex-1 bg-white text-primary hover:bg-white/90 font-bold rounded-xl"
                  onClick={() => toast({ title: "Withdrawal", description: "Processing transfer to your linked bank account..." })}
                >
                  <Banknote className="mr-2 h-4 w-4" />
                  Withdraw Funds
                </Button>
              ) : (
                <Button 
                  className="flex-1 bg-white text-primary hover:bg-white/90 font-bold rounded-xl"
                  onClick={() => toast({ title: "Deposit", description: "Payment gateway opening..." })}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Funds
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-bold">Recent History</h2>
            <Button variant="ghost" size="sm" className="text-xs text-primary">View all</Button>
          </div>
          
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div key={tx.id} className="bg-white p-4 rounded-2xl border flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-3">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                    tx.amount > 0 ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {tx.amount > 0 ? <ArrowDownLeft className="h-5 w-5 text-green-600" /> : <ArrowUpRight className="h-5 w-5 text-red-600" />}
                  </div>
                  <div>
                    <p className="text-sm font-bold">{tx.label}</p>
                    <p className="text-[10px] text-muted-foreground uppercase">{tx.type} • {tx.date}</p>
                  </div>
                </div>
                <span className={`font-bold ${tx.amount > 0 ? 'text-green-600' : 'text-accent'}`}>
                  {tx.amount > 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
