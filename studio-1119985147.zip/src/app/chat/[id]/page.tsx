
"use client";

import { use, useState, useEffect, useRef } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { SessionTimer } from "@/components/chat/session-timer";
import { ContentMarketplace } from "@/components/chat/content-marketplace";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, ChevronLeft, Info, MoreVertical } from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Message, ContentItem } from "@/lib/types";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";

const mockCreator = {
  id: "c1",
  name: "Aria Bloom",
  avatar: PlaceHolderImages[0].imageUrl,
};

const mockContent: ContentItem = {
  id: "content-1",
  creatorId: "c1",
  title: "Vibe Set: Midnight Mix",
  description: "Exclusive behind the scenes look at tonight's DJ set and the custom tracks I used.",
  price: 3.99,
  imageUrl: PlaceHolderImages[3].imageUrl,
  type: 'image',
};

export default function ChatPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      senderId: "system",
      text: "Session started. Enjoy your 45 minutes with Aria Bloom!",
      timestamp: new Date(),
      type: "system",
    },
    {
      id: "2",
      senderId: mockCreator.id,
      text: "Hey! Glad you're here. Ready to vibe out? 🎵",
      timestamp: new Date(),
      type: "text",
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [purchasedContent, setPurchasedContent] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = () => {
    if (!inputText.trim()) return;
    
    const newUserMsg: Message = {
      id: Date.now().toString(),
      senderId: "user-1",
      text: inputText,
      timestamp: new Date(),
      type: "text",
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputText("");

    // Simple bot response simulation
    setTimeout(() => {
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        senderId: mockCreator.id,
        text: "That's awesome! Check out this exclusive I just dropped ✨",
        timestamp: new Date(),
        type: "text",
      };
      
      const contentOffer: Message = {
        id: (Date.now() + 2).toString(),
        senderId: mockCreator.id,
        timestamp: new Date(),
        type: "content_offer",
        contentId: mockContent.id,
      };

      setMessages(prev => [...prev, botMsg, contentOffer]);
    }, 1000);
  };

  const handlePurchase = (contentId: string) => {
    // In real app, call payment API
    setPurchasedContent(prev => [...prev, contentId]);
    toast({
      title: "Content Unlocked!",
      description: "$3.99 has been sent to Aria Bloom.",
    });
  };

  return (
    <AppShell>
      <div className="flex flex-col h-[calc(100svh-64px)]">
        {/* Header */}
        <header className="px-4 py-3 border-b flex items-center justify-between bg-white sticky top-0 z-50">
          <div className="flex items-center gap-3">
            <Link href="/">
              <ChevronLeft className="h-6 w-6 text-muted-foreground" />
            </Link>
            <Avatar className="h-10 w-10">
              <AvatarImage src={mockCreator.avatar} />
              <AvatarFallback>{mockCreator.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-bold text-sm">{mockCreator.name}</h2>
              <div className="flex items-center gap-1">
                <div className="h-2 w-2 rounded-full bg-green-500" />
                <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-tight">Live Session</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon"><Info className="h-5 w-5" /></Button>
            <Button variant="ghost" size="icon"><MoreVertical className="h-5 w-5" /></Button>
          </div>
        </header>

        {/* Timer */}
        <SessionTimer 
          durationSeconds={2700} 
          onEnd={() => toast({ title: "Session Expired", description: "Pay $0.99 to continue." })}
        />

        {/* Messages */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-4 space-y-4 flex flex-col"
        >
          {messages.map((msg) => {
            if (msg.type === 'system') {
              return (
                <div key={msg.id} className="text-center py-2">
                  <span className="text-[10px] bg-muted-foreground/10 px-3 py-1 rounded-full text-muted-foreground font-medium">
                    {msg.text}
                  </span>
                </div>
              );
            }

            if (msg.type === 'content_offer') {
              return (
                <div key={msg.id} className="self-start">
                   <ContentMarketplace 
                    content={mockContent} 
                    onPurchase={handlePurchase}
                    isPurchased={purchasedContent.includes(msg.contentId!)}
                  />
                </div>
              );
            }

            const isUser = msg.senderId === 'user-1';
            return (
              <div 
                key={msg.id} 
                className={`chat-bubble ${isUser ? 'chat-bubble-user' : 'chat-bubble-creator'}`}
              >
                <p className="text-sm">{msg.text}</p>
                <span className={`text-[10px] block mt-1 opacity-70 ${isUser ? 'text-right' : 'text-left'}`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })}
        </div>

        {/* Input */}
        <div className="p-4 bg-white border-t safe-area-pb">
          <div className="flex items-center gap-2">
            <Input 
              placeholder="Type your vibe..." 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              className="rounded-full bg-muted border-none focus-visible:ring-primary h-12"
            />
            <Button 
              size="icon" 
              className="rounded-full h-12 w-12 shrink-0 bg-primary hover:bg-primary/90"
              onClick={sendMessage}
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
