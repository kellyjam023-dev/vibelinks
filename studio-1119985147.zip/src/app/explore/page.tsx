
"use client";

import { AppShell } from "@/components/layout/app-shell";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Search, SlidersHorizontal, Heart, MessageCircle } from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Link from "next/link";

const categories = ["All", "Music", "Art", "Gaming", "Life", "Dance", "Cooking"];

const allCreators = [
  { id: "c1", name: "Aria Bloom", category: "Music", followers: "12k", online: true, avatar: PlaceHolderImages[0].imageUrl },
  { id: "c2", name: "Marcus Ink", category: "Art", followers: "8.5k", online: true, avatar: PlaceHolderImages[1].imageUrl },
  { id: "c3", name: "Elena Chef", category: "Cooking", followers: "24k", online: false, avatar: PlaceHolderImages[2].imageUrl },
  { id: "c4", name: "DJ Spark", category: "Music", followers: "3k", online: true, avatar: PlaceHolderImages[4].imageUrl },
  { id: "c5", name: "Pixel Gamer", category: "Gaming", followers: "15k", online: true, avatar: PlaceHolderImages[3].imageUrl },
];

export default function ExplorePage() {
  return (
    <AppShell>
      <div className="p-6 space-y-6">
        <header className="space-y-4">
          <h1 className="text-2xl font-bold">Discover</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input className="pl-11 pr-11 rounded-full bg-white h-12 shadow-sm border-none focus-visible:ring-primary" placeholder="Search creators or tags" />
            <SlidersHorizontal className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-primary" />
          </div>
        </header>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
          {categories.map(cat => (
            <Badge 
              key={cat} 
              variant={cat === "All" ? "default" : "secondary"} 
              className="rounded-full px-4 py-1.5 whitespace-nowrap text-xs cursor-pointer"
            >
              {cat}
            </Badge>
          ))}
        </div>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-lg">Top Recommendation</h2>
            <span className="text-xs text-muted-foreground">Based on your vibes</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {allCreators.map(creator => (
              <Link key={creator.id} href={`/chat/${creator.id}`}>
                <Card className="border-none shadow-sm bg-white overflow-hidden hover:shadow-md transition-shadow">
                  <div className="aspect-square relative bg-muted">
                    <Avatar className="h-full w-full rounded-none">
                      <AvatarImage src={creator.avatar} className="object-cover" />
                      <AvatarFallback>{creator.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="absolute top-2 left-2">
                      <Badge className={creator.online ? "bg-green-500 hover:bg-green-500" : "bg-gray-400 hover:bg-gray-400"}>
                        {creator.online ? "Online" : "Away"}
                      </Badge>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent">
                       <p className="text-white font-bold text-sm truncate">{creator.name}</p>
                       <p className="text-white/80 text-[10px] uppercase font-bold tracking-tight">{creator.category}</p>
                    </div>
                  </div>
                  <CardContent className="p-3 flex justify-between items-center">
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      <Heart className="h-3 w-3 fill-primary text-primary" />
                      <span>{creator.followers}</span>
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground font-bold text-accent">
                      <MessageCircle className="h-3 w-3" />
                      <span>$0.99</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
