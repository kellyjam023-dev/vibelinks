
export type UserRole = 'user' | 'creator';
export type VerificationStatus = 'unverified' | 'pending' | 'verified' | 'rejected';

export interface Profile {
  id: string;
  name: string;
  role: UserRole;
  avatar: string;
  bio?: string;
  tags?: string[];
  balance: number;
  rating?: number;
  verificationStatus?: VerificationStatus;
}

export interface ContentItem {
  id: string;
  creatorId: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  type: 'image' | 'video';
}

export interface Message {
  id: string;
  senderId: string;
  text?: string;
  timestamp: Date;
  type: 'text' | 'content_offer' | 'system';
  contentId?: string;
  isPurchased?: boolean;
}

export interface ChatSession {
  id: string;
  userId: string;
  creatorId: string;
  startTime: Date;
  endTime: Date;
  status: 'active' | 'ended' | 'pending';
}
