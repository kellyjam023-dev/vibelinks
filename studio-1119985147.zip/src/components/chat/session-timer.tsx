
"use client";

import { useState, useEffect } from "react";
import { Timer, AlertCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface SessionTimerProps {
  durationSeconds: number;
  onEnd: () => void;
}

export function SessionTimer({ durationSeconds, onEnd }: SessionTimerProps) {
  const [timeLeft, setTimeLeft] = useState(durationSeconds);

  useEffect(() => {
    if (timeLeft <= 0) {
      onEnd();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onEnd]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const percentage = (timeLeft / durationSeconds) * 100;
  const isExpiring = timeLeft < 300; // 5 minutes

  return (
    <div className={cn(
      "sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b px-4 py-2 transition-colors",
      isExpiring ? "bg-red-50" : ""
    )}>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2 text-xs font-semibold">
          <Timer className={cn("h-4 w-4", isExpiring ? "text-red-500 animate-pulse" : "text-primary")} />
          <span className={isExpiring ? "text-red-600" : "text-muted-foreground"}>
            Session ends in {minutes}:{seconds.toString().padStart(2, '0')}
          </span>
        </div>
        {isExpiring && (
          <div className="text-[10px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full flex items-center gap-1 font-bold">
            <AlertCircle className="h-3 w-3" />
            Ending soon
          </div>
        )}
      </div>
      <Progress 
        value={percentage} 
        className="h-1.5" 
        indicatorClassName={isExpiring ? "bg-red-500" : "bg-primary"}
      />
    </div>
  );
}
