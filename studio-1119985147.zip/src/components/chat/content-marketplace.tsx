
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ContentItem } from "@/lib/types";
import Image from "next/image";
import { Lock, ShoppingCart } from "lucide-react";

interface ContentMarketplaceProps {
  content: ContentItem;
  onPurchase: (id: string) => void;
  isPurchased?: boolean;
}

export function ContentMarketplace({ content, onPurchase, isPurchased = false }: ContentMarketplaceProps) {
  return (
    <Card className="overflow-hidden border-2 border-primary/10 max-w-[280px] w-full self-start rounded-2xl bg-white shadow-sm">
      <div className="relative aspect-[3/4] w-full bg-muted">
        {!isPurchased ? (
          <div className="absolute inset-0 z-10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center text-white space-y-4">
            <div className="bg-white/20 p-3 rounded-full">
              <Lock className="h-8 w-8 text-white" />
            </div>
            <div>
              <h4 className="font-bold text-lg mb-1">{content.title}</h4>
              <p className="text-xs text-white/80">{content.description}</p>
            </div>
            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold"
              onClick={() => onPurchase(content.id)}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Unlock for $3.99
            </Button>
          </div>
        ) : (
          <Image
            src={content.imageUrl}
            alt={content.title}
            fill
            className="object-cover"
            data-ai-hint="creator content"
          />
        )}
      </div>
      {isPurchased && (
        <CardContent className="p-3">
          <h4 className="font-bold text-sm">{content.title}</h4>
          <p className="text-[10px] text-muted-foreground mt-1">Permanently unlocked in your history</p>
        </CardContent>
      )}
    </Card>
  );
}
