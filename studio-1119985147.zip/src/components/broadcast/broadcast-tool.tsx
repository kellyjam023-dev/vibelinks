
"use client";

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { improveBroadcastMessage } from "@/ai/flows/creator-broadcast-message-improvement";
import { Sparkles, Send, CheckCircle2, Loader2, Image as ImageIcon, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";

export function BroadcastTool() {
  const [message, setMessage] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isImproving, setIsImproving] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [selectedMedia, setSelectedMedia] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleImprove = async () => {
    if (!message.trim()) return;
    setIsImproving(true);
    try {
      const result = await improveBroadcastMessage({ message });
      setSuggestions(result.improvedMessages);
    } catch (error) {
      toast({ title: "AI Error", description: "Failed to improve message.", variant: "destructive" });
    } finally {
      setIsImproving(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedMedia(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = () => {
    setIsSent(true);
    toast({ title: "Broadcast Sent!", description: "Message and media sent to all active users." });
    setTimeout(() => {
      setIsSent(false);
      setMessage("");
      setSuggestions([]);
      setSelectedMedia(null);
    }, 3000);
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">Create Broadcast</CardTitle>
          <CardDescription>Reach your fans instantly. All active users will get a notification.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea 
            placeholder="What's happening? (e.g. New content drop in my chat!)"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="min-h-[120px] rounded-xl"
          />
          
          {selectedMedia && (
            <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-muted group">
              <Image src={selectedMedia} alt="Broadcast media" fill className="object-cover" />
              <Button 
                size="icon" 
                variant="destructive" 
                className="absolute top-2 right-2 h-8 w-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => setSelectedMedia(null)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          <div className="flex gap-2">
            <input 
              type="file" 
              accept="image/*,video/*" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileSelect}
            />
            <Button 
              variant="outline" 
              size="icon" 
              className="h-10 w-10 shrink-0 rounded-full border-primary text-primary"
              onClick={() => fileInputRef.current?.click()}
            >
              <ImageIcon className="h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              className="flex-1 rounded-full border-primary text-primary hover:bg-primary/5"
              onClick={handleImprove}
              disabled={isImproving || !message}
            >
              {isImproving ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="mr-2 h-4 w-4" />
              )}
              AI Improve
            </Button>
            <Button 
              className="flex-1 rounded-full bg-accent hover:bg-accent/90"
              onClick={handleSend}
              disabled={!message || isSent}
            >
              {isSent ? <CheckCircle2 className="mr-2 h-4 w-4" /> : <Send className="mr-2 h-4 w-4" />}
              {isSent ? "Sent!" : "Broadcast"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {suggestions.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-bold text-sm text-muted-foreground px-1 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            AI Suggestions
          </h3>
          {suggestions.map((suggestion, i) => (
            <Card key={i} className="bg-primary/5 border-primary/20 cursor-pointer hover:bg-primary/10 transition-colors" onClick={() => setMessage(suggestion)}>
              <CardContent className="p-4 text-sm italic">
                "{suggestion}"
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
