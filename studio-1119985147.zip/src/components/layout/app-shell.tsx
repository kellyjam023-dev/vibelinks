
import { BottomNav } from "@/components/navigation/bottom-nav";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background max-w-md mx-auto relative flex flex-col pb-20 shadow-xl border-x min-h-svh">
      <main className="flex-1 w-full overflow-y-auto">
        {children}
      </main>
      <BottomNav />
    </div>
  );
}
