
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, MessageSquare, Bell, Wallet, User, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const pathname = usePathname();
  const [role, setRole] = useState<'user' | 'creator'>('user');

  useEffect(() => {
    const updateRole = () => {
      const savedRole = localStorage.getItem('vibelinks-role') as 'user' | 'creator';
      setRole(savedRole || 'user');
    };

    updateRole();
    window.addEventListener('storage', updateRole);
    return () => window.removeEventListener('storage', updateRole);
  }, []);

  const navItems = [
    { icon: Home, label: "Home", path: "/dashboard" },
    ...(role === 'creator' ? [{ icon: Zap, label: "Studio", path: "/broadcast" }] : []),
    { icon: MessageSquare, label: "Chat", path: "/chats" },
    { icon: Bell, label: "Activity", path: "/notifications" },
    { icon: Wallet, label: "Wallet", path: "/wallet" },
    { icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-t h-16 safe-area-pb">
      <div className="flex justify-around items-center h-full max-w-md mx-auto px-4">
        {navItems.map((item) => {
          const isActive = pathname === item.path;
          return (
            <Link
              key={item.path}
              href={item.path}
              className={cn(
                "flex flex-col items-center justify-center space-y-1 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <item.icon className="h-6 w-6" strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
