
'use server';
/**
 * @fileOverview This file defines a Genkit flow for recommending creators to users based on their interests and past interactions.
 *
 * - userCreatorRecommendation - A function that handles the creator recommendation process.
 * - UserCreatorRecommendationInput - The input type for the userCreatorRecommendation function.
 * - UserCreatorRecommendationOutput - The return type for the userCreatorRecommendation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Input Schema for previous creator interactions
const PreviousInteractionSchema = z.object({
  creatorId: z.string().describe('The ID of the creator the user interacted with.'),
  interactionType:
    z.enum(['session', 'content_purchase', 'follow', 'like']).describe('The type of interaction (e.g., session, content_purchase).'),
  timestamp: z.string().datetime().describe('The timestamp of the interaction in ISO 8601 format.'),
});

// Input Schema for an available creator
const AvailableCreatorSchema = z.object({
  creatorId: z.string().describe('The unique ID of the creator.'),
  name: z.string().describe("The creator's name or handle."),
  bio: z.string().describe("A brief description of the creator's content and style."),
  contentTags: z
    .array(z.string())
    .describe('Tags describing the creator\u0027s content themes (e.g., "music", "art", "comedy").'),
});

// Input Schema for the overall recommendation flow
const UserCreatorRecommendationInputSchema = z.object({
  userId: z.string().describe('The unique ID of the user requesting recommendations.'),
  userInterests:
    z.array(z.string()).describe('A list of keywords or phrases describing the user\u0027s interests.'),
  previousCreatorInteractions: z
    .array(PreviousInteractionSchema)
    .optional()
    .describe('Optional: A history of the user\u0027s past interactions with creators.'),
  availableCreators:
    z.array(AvailableCreatorSchema).describe('A list of creators currently available on the platform for recommendation.'),
});
export type UserCreatorRecommendationInput = z.infer<typeof UserCreatorRecommendationInputSchema>;

// Output Schema for a recommended creator
const RecommendedCreatorSchema = z.object({
  creatorId: z.string().describe('The ID of the recommended creator.'),
  name: z.string().describe('The name of the recommended creator.'),
  reason: z.string().describe('A brief explanation of why this creator is recommended.'),
});

// Output Schema for the overall recommendation flow
const UserCreatorRecommendationOutputSchema = z.object({
  recommendedCreators: z
    .array(RecommendedCreatorSchema)
    .max(5) // Limit to a maximum of 5 recommendations
    .describe('A list of recommended creators for the user.'),
});
export type UserCreatorRecommendationOutput = z.infer<typeof UserCreatorRecommendationOutputSchema>;

// Exported wrapper function
export async function userCreatorRecommendation(
  input: UserCreatorRecommendationInput
): Promise<UserCreatorRecommendationOutput> {
  return userCreatorRecommendationFlow(input);
}

// Define the prompt for the creator recommendation
const creatorRecommendationPrompt = ai.definePrompt({
  name: 'creatorRecommendationPrompt',
  input: { schema: UserCreatorRecommendationInputSchema },
  output: { schema: UserCreatorRecommendationOutputSchema },
  prompt: `You are an AI-powered creator recommendation engine for Vibelinks. Your task is to analyze a user's interests and their previous interactions on the platform, then recommend creators from a given list that the user would most likely enjoy.\n\nHere is the user's information:\nUser ID: {{{userId}}}\nUser Interests: {{#each userInterests}}- {{{this}}}\n{{/each}}\n{{#if previousCreatorInteractions}}\nPrevious Interactions:\n{{#each previousCreatorInteractions}}- Creator ID: {{this.creatorId}}, Type: {{this.interactionType}}, Timestamp: {{this.timestamp}}\n{{/each}}\n{{else}}\nNo previous interactions found.\n{{/if}}\n\nHere is a list of available creators:\n{{#each availableCreators}}- Creator ID: {{this.creatorId}}, Name: {{this.name}}, Bio: {{this.bio}}, Content Tags: {{#each this.contentTags}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}\n{{/each}}\n\nBased on the user's interests and previous interactions, recommend up to 5 creators from the 'availableCreators' list. For each recommendation, provide the creator's ID, their name, and a brief reason why this creator is a good match. If no suitable creators are found, return an empty list.\n\nProvide your response in JSON format.`,
});

// Define the Genkit flow
const userCreatorRecommendationFlow = ai.defineFlow(
  {
    name: 'userCreatorRecommendationFlow',
    inputSchema: UserCreatorRecommendationInputSchema,
    outputSchema: UserCreatorRecommendationOutputSchema,
  },
  async (input) => {
    const { output } = await creatorRecommendationPrompt(input);
    return output!;
  }
);
