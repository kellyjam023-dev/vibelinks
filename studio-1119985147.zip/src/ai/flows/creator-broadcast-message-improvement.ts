
'use server';
/**
 * @fileOverview An AI agent that helps creators compose engaging broadcast messages.
 *
 * - improveBroadcastMessage - A function that handles the broadcast message improvement process.
 * - ImproveBroadcastMessageInput - The input type for the improveBroadcastMessage function.
 * - ImproveBroadcastMessageOutput - The return type for the improveBroadcastMessage function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ImproveBroadcastMessageInputSchema = z.object({
  message: z.string().describe('The creator\'s original broadcast message.'),
});
export type ImproveBroadcastMessageInput = z.infer<typeof ImproveBroadcastMessageInputSchema>;

const ImproveBroadcastMessageOutputSchema = z.object({
  improvedMessages: z.array(z.string()).describe('An array of improved broadcast message suggestions, each designed to be more engaging and attention-grabbing.'),
});
export type ImproveBroadcastMessageOutput = z.infer<typeof ImproveBroadcastMessageOutputSchema>;

export async function improveBroadcastMessage(input: ImproveBroadcastMessageInput): Promise<ImproveBroadcastMessageOutput> {
  return improveBroadcastMessageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'improveBroadcastMessagePrompt',
  input: { schema: ImproveBroadcastMessageInputSchema },
  output: { schema: ImproveBroadcastMessageOutputSchema },
  prompt: `You are an expert social media marketing assistant specializing in crafting engaging broadcast messages for content creators on a platform called Vibelinks. Your goal is to take a creator's original message and provide 3-5 distinct, improved versions that are more engaging, attention-grabbing, and likely to drive user interaction.

Consider the following points for improvement:
- Add clear calls to action (e.g., "Click here to watch!", "Join now!").
- Incorporate relevant emojis to increase visual appeal.
- Use dynamic and exciting language.
- Keep messages concise and impactful for a notification-style broadcast.
- The platform is called Vibelinks, and content is often sold for $3.99.

Original Message:
{{{message}}}

Provide your suggestions as a JSON object with a single key 'improvedMessages' which contains an array of strings. Each string in the array should be an improved message.
`,
});

const improveBroadcastMessageFlow = ai.defineFlow(
  {
    name: 'improveBroadcastMessageFlow',
    inputSchema: ImproveBroadcastMessageInputSchema,
    outputSchema: ImproveBroadcastMessageOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
