import { config } from 'dotenv';
config();

import '@/ai/flows/creator-broadcast-message-improvement.ts';
import '@/ai/flows/user-creator-recommendation.ts';